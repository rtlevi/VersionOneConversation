


How to use:

***URL CONFIGURATION
**Host
Got to package name com.davita.config

*File Name Configuration.java
This file page uses TestNG
Do not change anything in this file unless you have knowledge on TestNG

*File Name DataConfig.java
Replace the "****" in INPUT_FILE_Path line by your HOME computer Name.

 1. For mac users, change the ***** to your Home name...
	 - click on the finder, on top of the screen in the menu,
	 - click on go, and in the dropdown click on Home
	 - see the Home name probably your name i.e: rmarlyn  ..
	 
*File Name HostConfiguration.java

Replace the "****" in YOUR_COMPANY_HOST_URL line by your VersionOne curl
	
	 *****make sure you are and Admin in you versionOne change your username
	 
	 - UserName here: Delete the **** and replace with your credentials.
	 - password here: Delete the **** and replace with your credentials.
	 
	 
	 
	 
	 
	 *HOW TO RUN AND GET THE CONVERSATIONS
	 
	 Download STS tool "https://spring.io/tools/sts/all"  click on Based on Eclipse 4.6.3    (4.6.3 is the version of the tool)
	 Install STS 
	 Edit the file workspace-sts-3.8.3.RELEASE and change it to workspace-sts-4.6.3.RELEASE or to any version of your tool 
	 Download and save the project under Document folder in your computer
	 Open the project using STS tool Version 3.8.3 (Springboot)
	 Double click file ids.xls
	 Now in the xls file replace IDs by all IDs you want to import stories... and save
	 Close the xls file
	 Go back to STS tool
	 Open src/main/java
	 Open com.davita.restAssured
	 Right click file name Readers.java and click Run AS TestNG
	 
	 
	 
	 
	 Problems:
	 1. You don't see TestNG under Run AS
	 Response: please follow this link on how to install testNG in Eclipse,
	 it is very simple.
	 http://toolsqa.com/selenium-webdriver/install-testng/
	 
	 Once done you should be able to run them by re-doing the same steps specified above
	 
	 Question ? 
	 ---------
	 Just create a test result here, please add your email in the comment and I will help you out!
	 
	 http://zandokin.com/siliconbigdata/
	 
	 

	 
	 
	 Note : 
	 This is a maven project.
	 This is a java base code project
	 Make sure to refresh/update maven.. the project so that it downloads all the dependencies
	 
	 
	 
	 